#!/bin/bash
set -euo pipefail

log_file="logfile.log"

echo "" > "$log_file"


# this will not be triggered by checking the Debug checkbox on the workflow re-run
# needs to be set as a variable in the workflow
ACTIONS_STEP_DEBUG=${ACTIONS_STEP_DEBUG:-false}

get_maintainers() {
    echo "jmartasek"
    echo "resd-github-admin"
}

get_team_file() {
    local team_name=$1
    local team_file="users/$team_name.txt"

    echo "$team_file"
}

get_expected_team_users() {
    local team_name=$1
    local team_file=$(get_team_file "$team_name")

    if [[ ! -f $team_file ]]; then
        echo "Error: Missing corresponding users file for team $team_name - $team_file." | tee -a "$log_file"
        exit 1
    fi

    cat "$team_file"
}

get_current_team_users() {
    # retrieve a list of users from a GitHub team
    local team_name=$1

    # get the team id
    local team_id
    # team_id=$(gh api "orgs/EliLillyCo/teams/$team_name" --jq '.id')
    # HACK: should we have more than 100 members, this will not work
    query="{ organization(login: \"EliLillyCo\") { team(slug: \"$team_name\") { members(first: 100, membership: IMMEDIATE) { nodes { login } } } } }"

    # get the list of members
    # gh api "orgs/EliLillyCo/teams/$team_name/members" --jq '.[].login' --paginate  # this will retrieve members of the child teams too
    gh api graphql -f query="$query" --jq '.data.organization.team.members.nodes[].login'
}

validate_expected_team_users() {
    # validate that all users in the team file are valid GitHub users
    local team_name=$1
    local team_file=$(get_team_file "$team_name")
    local line_num=0
    local error_found=0

    echo "Validating team $team_name" | tee -a "$log_file"

    # Check that team exists and raise error if not
    if ! gh api "orgs/EliLillyCo/teams/$team_name" --jq '.login' > /dev/null; then
        echo "::error file=$team_file::Invalid team: $team_name"
        echo "Error: Team $team_name does not exist." | tee -a "$log_file"
        exit 1
    fi
    echo "Team $team_name is valid" | tee -a "$log_file"

    while IFS= read -r username; do
        line_num=$((line_num + 1))
        # echo "Validating user $username on line $line_num"
        if ! gh api "/orgs/EliLillyCo/members/$username" > /dev/null; then
            echo "::error file=$team_file,line=$line_num::Invalid username (maybe the user is not in EliLillyCo organisation yet): $username"
            echo "Error: Invalid username (maybe the user is not in EliLillyCo organisation yet): $username" | tee -a "$log_file"
            error_found=1
        fi
    done < "$team_file"

    if [[ $error_found -eq 1 ]]; then
        exit 1
    fi

    echo "All users in team $team_name are valid" | tee -a "$log_file"
}

ensure_maintainers() {
    local team_name=$1
    local perform_sync=$2
    local -a maintainers=()
    mapfile -t maintainers < <(get_maintainers)

    # If perform_sync is not 1, then we are in dry-run mode
    if [[ $perform_sync -ne 1 ]]; then
        # print the list of maintainers
        echo "Dry run - Maintainers:" | tee -a "$log_file"
        printf '%s\n' "${maintainers[@]}" | tee -a "$log_file"
        return
    fi

    # Set all maintainers to maintainer role, add them if they are not already members
    for maintainer in "${maintainers[@]}"; do
        gh api "orgs/EliLillyCo/teams/$team_name/memberships/$maintainer" -X PUT -F role=maintainer
    done

}

sync_team() {
    local team_name=$1
    local perform_sync=$2

    # Get the list of users from the team's file
    local -a expected_team_users
    mapfile -t expected_team_users < <(get_expected_team_users "$team_name")

    # Get the list of users from the GitHub team
    local -a current_team_users
    mapfile -t current_team_users < <(get_current_team_users "$team_name")

    # Get the list of maintainers
    local -a maintainers
    mapfile -t maintainers < <(get_maintainers)

    ensure_maintainers "$team_name" "$perform_sync"

    # add all the maintainers to expected_team_users
    expected_team_users+=("${maintainers[@]}")

    # for each user in the expected_team_users
    # if the user is in current_team_users add to to_be_kept list
    # else - add the user to to_be_added list
    local -a to_be_added=()
    local -a to_be_kept=()
    local -a to_be_removed=()
    local user
    # For each user in expected_team_users
    for user in "${expected_team_users[@]}"; do
        # if the user is in current_team_users add to to_be_kept list
        if [[ " ${current_team_users[@]} " =~ " $user " ]]; then
            to_be_kept+=("$user")
        # else - add the user to to_be_added list
        else
            to_be_added+=("$user")
        fi
    done

    # For each user in current_team_users
    # if the user is not in the to_be_kept list, add the user to the to_be_removed list
    for user in "${current_team_users[@]}"; do
        if [[ ! " ${to_be_kept[@]} " =~ " $user " ]]; then
            to_be_removed+=("$user")
        fi
    done


    # Print the results
    echo "Team: $team_name" | tee -a "$log_file"
    echo "Maintainers:" | tee -a "$log_file"
    printf '%s\n' "${maintainers[@]}" | tee -a "$log_file"

    # Only print if ACTIONS_STEP_DEBUG
    if [[ "$ACTIONS_STEP_DEBUG" == "true" ]]; then
        echo "Expected users:" | tee -a "$log_file"
        printf '%s\n' "${expected_team_users[@]}" | tee -a "$log_file"
        echo "Current users:" | tee -a "$log_file"
        printf '%s\n' "${current_team_users[@]}" | tee -a "$log_file"
        echo "To be kept:" | tee -a "$log_file"
        printf '%s\n' "${to_be_kept[@]}" | tee -a "$log_file"
    fi

    echo "To be added:" | tee -a "$log_file"
    printf '%s\n' "${to_be_added[@]}" | tee -a "$log_file"
    echo "To be removed:" | tee -a "$log_file"
    printf '%s\n' "${to_be_removed[@]}" | tee -a "$log_file"

    # if $GITHUB_STEP_SUMMARY is defined
    # Add the results as markdown to $GITHUB_STEP_SUMMARY
    if [[ -n ${GITHUB_STEP_SUMMARY:-} ]]; then
        echo "## Team: $team_name" >> $GITHUB_STEP_SUMMARY
        echo "### Maintainers:" >> $GITHUB_STEP_SUMMARY
        printf '%s\n' "${maintainers[@]}" >> $GITHUB_STEP_SUMMARY

        # Only print if ACTIONS_STEP_DEBUG
        if [[ $ACTIONS_STEP_DEBUG == true ]]; then
            echo "### Expected users:" >> $GITHUB_STEP_SUMMARY
            printf '%s\n' "${expected_team_users[@]}" >> $GITHUB_STEP_SUMMARY
            echo "### Current users:" >> $GITHUB_STEP_SUMMARY
            printf '%s\n' "${current_team_users[@]}" >> $GITHUB_STEP_SUMMARY
            echo "### To be kept:" >> $GITHUB_STEP_SUMMARY
            printf '%s\n' "${to_be_kept[@]}" >> $GITHUB_STEP_SUMMARY
        fi

        echo "### To be added:" >> $GITHUB_STEP_SUMMARY
        printf '%s\n' "${to_be_added[@]}" >> $GITHUB_STEP_SUMMARY

        echo "### To be removed:" >> $GITHUB_STEP_SUMMARY
        printf '%s\n' "${to_be_removed[@]}" >> $GITHUB_STEP_SUMMARY
        echo "" >> $GITHUB_STEP_SUMMARY
    fi

    if [[ $perform_sync -eq 1 ]]; then
        # Add users to the team
        for user in "${to_be_added[@]}"; do
            echo "Adding user $user to team $team_name"
            gh api "orgs/EliLillyCo/teams/$team_name/memberships/$user" -X PUT
        done

        # Remove users from the team
        for user in "${to_be_removed[@]}"; do
            echo "Removing user $user from team $team_name"
            gh api "orgs/EliLillyCo/teams/$team_name/memberships/$user" -X DELETE
        done
    fi
}


# if this is run as a script and not sourced
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    validate_expected_team_users $1
    sync_team $1 0
fi


# ensure_maintainers $1 1

# input - team name
# output - list of users to be added, removed and kept

# check the team exists
# ensure all the maintainers are assigned maintaner role

# pull the list of all users of the team - current_team_users
# read all users from the team's file - expected_team_users
    # add all the maintaners to expected_team_users

# for each user in the expected_team_users
    # if the user is in current_team_users add to to_be_kept list
    # else - add the user to to_be_added list

# for each user in current_team_users
    # if the user is not to_be_kept list add the user to to_be_removed list
